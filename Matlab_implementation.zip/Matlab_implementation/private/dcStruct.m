function s = dcStruct(prefix,xName,yName,suffix,dcFun)
s.prefix = prefix;
s.xName = xName;
s.yName = yName;
s.suffix = suffix;
s.dcFun = dcFun;
end