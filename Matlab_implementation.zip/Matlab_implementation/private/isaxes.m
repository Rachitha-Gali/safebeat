function tf = isaxes(ax)
tf = strcmp({ax.Type},'axes');
end