function tf = isfigure(f)
tf = strcmp({f.Type},'figure');
end